from landscape import Configuration, Node
from sensors import Sensor
import numpy as np
import pprint as pp
import os
import shutil
from pathlib import Path
from scipy.optimize import minimize
from scipy import optimize
import time
from make_map import make_basic_seismic_map
import matplotlib.pyplot as plt
from make_target_map import add_targets
from sensor_vision import sensor_vision, sensor_reading, target_localization_both, target_localization_bearing, target_localization_radius
from fisher_information import build_FIM, build_map_FIMS
from localization_calculations import sensor_localization_routine


'''
This script:
1. Visualizes the "sensor vision," or what each sensor sees
2. Localizes p targets with N arbitrary sensors
3. Returns the estimates of the target locations 
4. Calculates the FIM about each point and the FIM score amongst the entire map

TO DO (in order of importance):
'''

# --------------PARAMETERS------------------
# TERRAIN INPUTS
terrain_height = 100 #796
terrain_width = 100 #1002
terrain = Configuration(terrain_width, terrain_height)
my_path = Path(__file__).parent / "../data/terrain/GIS_terrain_resize.csv"
terrain.load_from_csv(my_path)

# SENSOR LIST
sensor_rad = [25, 25, 25, 20, 20]
sensor_type = ["acoustic","seismic","seismic","acoustic", "seismic"]
num_sensors = len(sensor_type)
sensor_comm_ratio = 1 # ratio of sensor communication to sensing radius 
meas_type = ["bearing", "radial", "radial", "bearing", "radial"] #"bearing" or "radial" options
sensor_locs = [57, 58, 36, 46, 66, 36, 75, 64, 44, 16]
targets = [40, 60, 50, 50, 63, 75, 48, 33, 88, 40]
# ------------------------------------------

# BUILD THE MAP
_map = make_basic_seismic_map(num_sensors, sensor_rad, sensor_type, sensor_comm_ratio, sensor_locs)
score = terrain.get_configuration_observability(_map)
ax = terrain.plot_grid(_map)
new_map = add_targets(ax, targets)

## DETERMINE THE LOCALIZABLE TARGETS
# Conditions: (1) a target is seen by two bearing sensors
            # (2) a target is seen by a bearing and a radius
            # (3) a target is seen by three radii sensors

# Will return a list of lists, where each list is sensor positions
# and sensor types that can localize the target. The number of elements 
# in the larger list will correspond to the number of targets

# Coded up in "sensor_localization_routine" fcn
inputs = sensor_rad, meas_type, sensor_locs, targets, ax
(target_localized_successfully, ax) = sensor_localization_routine(inputs)

## FIM CALCULATION
# For each target that is localized, calculate the FIM about that point
# For each target, create sublists of sensors that see the target

# Coded up in "fisher_information.py"
inputs = target_localized_successfully, targets, sensor_locs, sensor_rad,meas_type
(FIMs, det_sum) = build_map_FIMS(inputs)

print("MAP FIM SCORE")
# print(FIMs)
print(det_sum)

plt.show()
