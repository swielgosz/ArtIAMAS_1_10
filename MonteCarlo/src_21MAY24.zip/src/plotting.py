from landscape import Configuration, Node
from sensors import Sensor
import numpy as np
import pprint as pp
import os
import shutil
from pathlib import Path
from scipy.optimize import minimize
from scipy import optimize
import time
from make_map import make_basic_seismic_map
from make_target_map import add_targets, add_targets_localized
sensor_comm_ratio = 1.5
import matplotlib.pyplot as plt

# Fcn accepts a list of sensor radii, corresponding type, and location
# The sensors in the list are placed on the map

terrain_height = 600
terrain_width = 600
terrain = Configuration(terrain_width, terrain_height)
my_path = Path(__file__).parent / "../data/terrain/GIS_terrain_cropped.csv"
terrain.load_from_csv(my_path)

x_final = [6*37,6*47,6*40,6*41,6*16,6*32,6*23,6*45]
targets = [39, 42, 35, 58, 50, 50, 27, 22, 63, 35, 53, 16, 15, 30]
targets = [6*i for i in targets]

'''
# Create a plot with targets
_map = make_basic_seismic_map(0, [], [], [], 1, [])
fig = plt.figure()
ax = terrain.plot_grid(_map)
new_map = add_targets(ax, targets)
ax.set_ylabel('Longitude'), ax.set_xlabel('Latitude')
ax.set_title('Initial Environment with Unknown Targets')
plt.show()
'''


# Create a plot with targets and sensors
num_sensors = 5
sensor_rad = [15*6, 15*6, 20*6, 20*6, 10*6, 20*6]
sensor_type = ["acoustic", "acoustic", "seismic", "seismic", "acoustic"]
sensor_mode = ["radius", "radius", "bearing", "bearing", "radius"] #bearing or radius
sensor_locs = [34, 22, 54, 53, 33, 29, 40, 51, 33, 61]

# For replacement
num_sensors = 7
#sensor_rad = [15*6, 15*6, 20*6, 20*6, 10*6, 20*6, 17*6, 20*6]
#sensor_type = ["acoustic", "acoustic", "seismic", "seismic", "acoustic", "acoustic", "seismic"]
#sensor_mode = ["radius", "radius", "bearing", "bearing", "radius", "radius", "bearing"] #bearing or radius
#sensor_locs = [34, 22, 54, 53, 33, 29, 40, 51, 33, 61, 29, 41, 55, 36]


sensor_locs = [6*i for i in sensor_locs]
localized = [1, 1, 1, 1, 0, 0, 0] # corresponds to number of target
fig = plt.figure()
_map_init = make_basic_seismic_map(num_sensors, sensor_rad, sensor_type, sensor_mode, sensor_comm_ratio, sensor_locs)
ax = terrain.plot_grid(_map_init)
ax = add_targets_localized(ax, targets, localized)
ax.set_ylabel('Longitude'), ax.set_xlabel('Latitude')
ax.set_title('Additional Sensor Placement')
plt.show()