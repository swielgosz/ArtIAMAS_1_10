import numpy as np

def build_FIM(sensors, target, sensor_types, sigma_e):
    '''
    Calculate the fisher information matrix for:
    1 point and
    N homogenous sensors that see a target
    about the localized target, p
    
    Returns the FIM following sources [1], [3]
    '''

    # Need to first generate a list of phi's and r'i
    phi = []
    r = []

    # Construct a phi for each sensor relative to a single pt
    for i in range(len(sensors)//2):
        xi, yi = sensors[0+2*i], sensors[1+2*i]
        dx, dy = (xi- target[0]), (yi - target[1])
        ri = (dx**2+dy**2)**(1/2)
        if np.isclose(dx, 0, rtol=1e-06) == True:
            phi_i = np.pi
        else:
            phi_i = np.arctan2(dy, dx)

        phi.append(phi_i)
        r.append(ri)

    #print("phi list:", phi)
    #print("r list:", r)

    # Consturct the matrix
    FIM = np.array(([0.,0.],[0.,0.]))
    for i in range(len(phi)):

        if sensor_types[i] == "bearing":
            # If the sensor is placed on the target, avoid div by 0 error
            if np.isclose(r[i], 0, rtol=1e-06) == True:
                FIM += (1/(1)**2)*np.array(([(np.cos(phi[i]))**2,-0.5*np.sin(2*phi[i])],
                                [-0.5*np.sin(2*phi[i]),(np.sin(phi[i]))**2]))
            else: #note: should be 1/r^2, but I'm testing stuff - JM
                FIM += (1/(r[i])**2)*np.array(([(np.cos(phi[i]))**2,-0.5*np.sin(2*phi[i])],
                                [-0.5*np.sin(2*phi[i]),(np.sin(phi[i]))**2]))
        
        if sensor_types[i] == "radial":
            FIM += np.array(([(np.sin(phi[i]))**2,0.5*np.sin(2*phi[i])],
                            [0.5*np.sin(2*phi[i]),(np.cos(phi[i]))**2]))
           
        FIM = FIM*(1/sigma_e[i])**2

    return FIM

def build_map_FIMS(inputs):

    target_localized_successfully, targets, sensor_locs, sensor_rad,meas_type, sigmas = inputs

    FIMs = []
    det_sum = 0.
    for i in range(len(targets)//2):
        sub_sensor_FIM = []
        sub_sensor_type = []

        # For unlocalized targets
        if target_localized_successfully[i] == 0:
            FIM_p = np.array(([0, 0],[0,0]))
            FIMs.append(FIM_p)
            det_sum += np.linalg.det(FIMs[i])
        
        # For localized targets
        elif target_localized_successfully[i] == 1:
            xt, yt = targets[0+2*i], targets[1+2*i]
            
            # Check if the sensor sees the target
            for j in range(len(sensor_locs)//2):
                x, y = sensor_locs[0+2*j], sensor_locs[1+2*j]
                dist = ((x-xt)**2+(y-yt)**2)**(1/2)
                if dist < sensor_rad[j]:
                    sub_sensor_FIM.append(x)
                    sub_sensor_FIM.append(y)
                    sub_sensor_type.append(meas_type[j])
            
            # Take the sub-list of sensors that see a target
            # and calculate the FIM
            FIMs.append(build_FIM(sub_sensor_FIM, [xt, yt], sub_sensor_type, sigmas))
            det_sum += np.linalg.det(FIMs[i])

    return FIMs, det_sum


def plot_uncertainty_ellipse(_map, FIM, target, confidence):
    '''
    #Accepts: map to plot, FIM cooresponding to ONE target, and one target
    #Returns: plotted map w/ uncertainty ellipse plotted at target
    '''
    Cov_Mat = np.linalg.inv(FIM)

    sx = (Cov_Mat[0,0])*confidence     #radius on the x-axis
    sy = (Cov_Mat[1,1])*confidence     #radius on the y-axis
    sxy = (Cov_Mat[0,1])*confidence     #covariance terms
    
    a2 = (sx**2+sy**2)/2 + (((sx**2-sy**2)**2 )/ 4 + sxy**2)**(1/2)
    b2 = (sx**2+sy**2)/2 - (((sx**2-sy**2)**2 )/ 4 + sxy**2)**(1/2)

    a = a2**(1/2)
    b = b2**(1/2)

    theta = (1/2)*np.arctan2(2*sxy, sx**2-sy**2)

    u=target[0]     #x-position of the center
    v=target[1]     #y-position of the center
    
    print("ellipse area:", np.pi*a*b)

    t = np.linspace(0, 2*np.pi, 100)
    _map.plot( u+a**(1/2)*np.cos(t)*np.cos(theta) - b**(1/2)*np.sin(theta)*np.sin(t), 
              v+a**(1/2)*np.cos(t)*np.sin(theta) - b**(1/2)*np.cos(theta)*np.sin(t) )

    return _map
