# Sensor class

class Sensor():
    def __init__(self, radius, cost=10):
        # Attributes
        self.radius = radius
        self.cost = cost