class target:
    def __init__(self):
        self.color = (238, 75, 43)